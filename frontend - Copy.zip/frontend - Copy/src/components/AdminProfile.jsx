import React, { useState, useEffect } from "react";
import {
  User,
  Shield,
  Settings,
  Bell,
  Camera,
  Save,
  Edit3,
  Calendar,
} from "lucide-react";
import "../styles/AdminProfilePage.css";
import { apiFetch } from "../../../fetching"; // Adjust the path as needed

export default function AdminProfilePage() {
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState("profile");
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    location: "",
    role: "",
    department: "",
    joinDate: "",
    bio: "",
  });

  const [notifications, setNotifications] = useState({
    email: false,
    push: false,
    sms: false,
    security: false,
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch initial profile data when the component mounts
  useEffect(() => {
    const fetchProfileData = async () => {
      try {
        const data = await apiFetch("/api/admin-profile/"); // Use your actual API endpoint for admin profile
        setFormData(data);
        // Assuming notifications are part of the profile data
        if (data.notifications) {
          setNotifications(data.notifications);
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchProfileData();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleNotificationChange = (type) => {
    setNotifications((prev) => ({ ...prev, [type]: !prev[type] }));
  };

  // Function to save profile data to the API
  const handleSaveProfile = async () => {
    try {
      await apiFetch("/api/admin-profile/", {
        method: "PUT", // Or POST, depending on your API
        body: JSON.stringify({ ...formData, notifications }),
      });
      setIsEditing(false);
      alert("Profile updated successfully!");
    } catch (err) {
      console.error("Failed to save profile:", err);
      alert("Failed to save profile. Please try again.");
    }
  };

  const renderProfileTab = () => (
    <div className="tab-section profile-section">
      <div className="profile-actions">
        {isEditing ? (
          <button className="icon-btn" onClick={handleSaveProfile}>
            <Save size={20} />
            <span>Save</span>
          </button>
        ) : (
          <button className="icon-btn" onClick={() => setIsEditing(true)}>
            <Edit3 size={20} />
            <span>Edit Profile</span>
          </button>
        )}
      </div>

      <div className="profile-details-grid">
        <div className="detail-item">
          <label htmlFor="firstName">First Name</label>
          <input
            type="text"
            id="firstName"
            name="firstName"
            value={formData.firstName}
            onChange={handleInputChange}
            disabled={!isEditing}
          />
        </div>
        <div className="detail-item">
          <label htmlFor="lastName">Last Name</label>
          <input
            type="text"
            id="lastName"
            name="lastName"
            value={formData.lastName}
            onChange={handleInputChange}
            disabled={!isEditing}
          />
        </div>
        <div className="detail-item">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            disabled={!isEditing}
          />
        </div>
        <div className="detail-item">
          <label htmlFor="phone">Phone</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleInputChange}
            disabled={!isEditing}
          />
        </div>
        <div className="detail-item full-width">
          <label htmlFor="location">Location</label>
          <input
            type="text"
            id="location"
            name="location"
            value={formData.location}
            onChange={handleInputChange}
            disabled={!isEditing}
          />
        </div>
        <div className="detail-item">
          <label htmlFor="role">Role</label>
          <input
            type="text"
            id="role"
            name="role"
            value={formData.role}
            onChange={handleInputChange}
            disabled={!isEditing}
          />
        </div>
        <div className="detail-item">
          <label htmlFor="department">Department</label>
          <input
            type="text"
            id="department"
            name="department"
            value={formData.department}
            onChange={handleInputChange}
            disabled={!isEditing}
          />
        </div>
        <div className="detail-item full-width">
          <label htmlFor="bio">About Me</label>
          <textarea
            id="bio"
            name="bio"
            value={formData.bio}
            onChange={handleInputChange}
            disabled={!isEditing}
            rows="4"
          />
        </div>
      </div>
    </div>
  );

  const renderSecurityTab = () => (
    <div className="tab-section security-section">
      <p>Security settings are not yet available.</p>
      {/* Additional security content can be added here */}
    </div>
  );

  const renderNotificationsTab = () => (
    <div className="tab-section notifications-section">
      <h3>Notification Preferences</h3>
      <div className="notification-item">
        <label htmlFor="email-notif">Email Notifications</label>
        <input
          type="checkbox"
          id="email-notif"
          name="email-notif"
          checked={notifications.email}
          onChange={() => handleNotificationChange("email")}
        />
      </div>
      <div className="notification-item">
        <label htmlFor="push-notif">Push Notifications</label>
        <input
          type="checkbox"
          id="push-notif"
          name="push-notif"
          checked={notifications.push}
          onChange={() => handleNotificationChange("push")}
        />
      </div>
    </div>
  );

  const renderSettingsTab = () => (
    <div className="tab-section settings-section">
      <p>User settings are not yet available.</p>
    </div>
  );

  if (loading) {
    return <div className="loading-state">Loading profile...</div>;
  }

  if (error) {
    return <div className="error-state">Error: {error}</div>;
  }

  return (
    <div className="admin-profile-page">
      <header className="profile-header">
        <div className="profile-image-placeholder">
          <Camera size={24} />
        </div>
        <div className="profile-info-header">
          <h1>
            {formData.firstName} {formData.lastName}
          </h1>
          <p className="profile-role">{formData.role}</p>
          <p className="profile-email">{formData.email}</p>
        </div>
      </header>

      <div className="profile-content">
        <main className="profile-main-content">
          <nav className="profile-tabs">
            {[
              { id: "profile", label: "Profile", icon: User },
              { id: "security", label: "Security", icon: Shield },
              { id: "notifications", label: "Notifications", icon: Bell },
              { id: "settings", label: "Settings", icon: Settings },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  className={`tab-btn ${activeTab === tab.id ? "active" : ""}`}
                  onClick={() => setActiveTab(tab.id)}
                >
                  <Icon size={16} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
          <div className="tab-content">
            {activeTab === "profile" && renderProfileTab()}
            {activeTab === "security" && renderSecurityTab()}
            {activeTab === "notifications" && renderNotificationsTab()}
            {activeTab === "settings" && renderSettingsTab()}
          </div>
        </main>

        <section className="quick-stats-grid">
          <div className="stat-card">
            <Calendar className="icon-blue" />
            <div className="stat-info">
              <p className="stat-label">Member Since</p>
              <p className="stat-value">
                {formData.joinDate
                  ? new Date(formData.joinDate).toLocaleDateString("en-US", {
                      month: "short",
                      year: "numeric",
                    })
                  : "N/A"}
              </p>
            </div>
          </div>
          <div className="stat-card">
            <Shield className="icon-green" />
            <div className="stat-info">
              <p className="stat-label">Security Score</p>
              <p className="stat-value">85%</p>
            </div>
          </div>
          <div className="stat-card">
            <User className="icon-purple" />
            <div className="stat-info">
              <p className="stat-label">Role Level</p>
              <p className="stat-value">Admin</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
