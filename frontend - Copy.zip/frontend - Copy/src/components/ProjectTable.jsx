import React, { useState, useEffect, useMemo, useRef } from "react";
import countriesData from "../data/countriesminified.json"; // local JSON
import { Link, useParams } from "react-router-dom";
import { Plus, Edit, Trash2 } from "lucide-react"; // Import Edit and Trash2 icons
import { apiFetch } from "../../../fetching"; // Adjust the path as needed

const ProjectTable = () => {
  const { projectType } = useParams();
  const [activeTab, setActiveTab] = useState("ongoing");
  const [selectedRegion, setSelectedRegion] = useState("");
  const [selectedCountry, setSelectedCountry] = useState("");
  const [projects, setProjects] = useState([]); // State for projects
  const [loading, setLoading] = useState(true); // State for loading status
  const [error, setError] = useState(null); // State for errors

  const btnRef = useRef(null);

  // Function to fetch projects from the API
  useEffect(() => {
    const fetchProjects = async () => {
      try        {
        setLoading(true);
        const data = await apiFetch("/api/projects/"); // Use your actual API endpoint
        setProjects(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchProjects();
  }, []);

  const handleMouseMove = (e) => {
    if (btnRef.current) {
      const rect = btnRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      btnRef.current.style.setProperty("--x", `${x}px`);
      btnRef.current.style.setProperty("--y", `${y}px`);
    }
  };

  const handleEditProject = (projectId) => {
    alert(`Editing project with ID: ${projectId}`);
    // You would use apiFetch here for a PUT request
    // e.g., apiFetch(`/api/projects/${projectId}/`, { method: 'PUT', body: JSON.stringify(updatedData) });
  };

  const handleDeleteProject = async (projectId) => {
    const isConfirmed = window.confirm(
      `Are you sure you want to delete project ${projectId}?`
    );
    if (!isConfirmed) {
      return;
    }

    try {
      await apiFetch(`/api/projects/${projectId}/`, { method: "DELETE" });
      setProjects((prevProjects) =>
        prevProjects.filter((p) => p.id !== projectId)
      );
      alert("Project deleted successfully!");
    } catch (err) {
      console.error("Failed to delete project:", err);
      alert("Failed to delete project. Please try again.");
    }
  };

  // --- Custom Regions
  const customRegions = {
    "Middle East": [
      { name: "United Arab Emirates" },
      { name: "Saudi Arabia" },
      { name: "Qatar" },
      { name: "Oman" },
      { name: "Bahrain" },
      { name: "Kuwait" },
      { name: "Israel" },
      { name: "Jordan" },
      { name: "Lebanon" },
      { name: "Egypt" },
      { name: "Turkey" },
    ],
    "Asia Pacific": [
      { name: "China" },
      { name: "Japan" },
      { name: "South Korea" },
      { name: "India" },
      { name: "Australia" },
      { name: "New Zealand" },
      { name: "Singapore" },
      { name: "Malaysia" },
      { name: "Indonesia" },
      { name: "Thailand" },
      { name: "Vietnam" },
      { name: "Philippines" },
    ],
  };

  // --- Static Lists for Select Components ---
  const regionOptions = useMemo(() => {
    const regionsFromFile = Array.from(
      new Set(countriesData.map((c) => c.region).filter((r) => r))
    );
    const customRegionNames = Object.keys(customRegions);
    const allUniqueRegionNames = new Set([
      ...regionsFromFile,
      ...customRegionNames,
    ]);
    return Array.from(allUniqueRegionNames).sort();
  }, []);

  const countryOptions = useMemo(() => {
    if (!selectedRegion) {
      return [];
    }
    if (customRegions[selectedRegion]) {
      return customRegions[selectedRegion].map((c) => c.name);
    } else {
      return countriesData
        .filter((c) => c.region === selectedRegion)
        .map((c) => c.name)
        .sort();
    }
  }, [selectedRegion]);

  // --- Status Helpers ---
  const getStatusClass = (status) => {
    switch (status) {
      case "completed":
        return "status-completed";
      case "in-progress":
        return "status-progress";
      case "rejected":
        return "status-rejected";
      default:
        return "";
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case "completed":
        return "Completed";
      case "in-progress":
        return "Ongoing";
      case "rejected":
        return "Rejected";
      default:
        return status;
    }
  };

  const handleViewProject = (projectId) => {
    alert(`Navigating to overview for project ID: ${projectId}`);
  };

  // --- Memoized Filtered Projects ---
  const filteredProjects = useMemo(() => {
    let filtered = projects;

    if (projectType) {
      filtered = filtered.filter(
        (project) => project.type?.toLowerCase() === projectType.toLowerCase()
      );
    }

    if (activeTab === "ongoing") {
      filtered = filtered.filter((p) => p.status === "in-progress");
    } else if (activeTab === "completed") {
      filtered = filtered.filter((p) => p.status === "completed");
    } else if (activeTab === "negotiation") {
      filtered = filtered.filter((p) => p.status === "rejected");
    } else if (activeTab === "regions") {
      filtered = filtered.filter((p) => {
        const matchesRegion = !selectedRegion || p.region === selectedRegion;
        const matchesCountry =
          !selectedCountry || p.country === selectedCountry;
        return matchesRegion && matchesCountry;
      });
    }
    return filtered;
  }, [activeTab, projects, selectedRegion, selectedCountry, projectType]);

  if (loading) {
    return <div className="project-summary">Loading projects...</div>;
  }

  if (error) {
    return <div className="project-summary error-message">Error: {error}</div>;
  }

  return (
    <div className="project-summary">
      <div className="summary-header">
        <h2>Project List</h2>
        <span className="header-right">
          <Link
            to="/add-project"
            className="add-project-btn"
            ref={btnRef}
            onMouseMove={handleMouseMove}
          >
            <Plus className="plus-icon" size={18} />
            Add New Project
          </Link>
        </span>
      </div>

      <div className="tabs">
        <div
          className={`tab ${activeTab === "ongoing" ? "active" : ""}`}
          onClick={() => setActiveTab("ongoing")}
        >
          Ongoing
        </div>
        <div
          className={`tab ${activeTab === "negotiation" ? "active" : ""}`}
          onClick={() => setActiveTab("negotiation")}
        >
          Negotiation
        </div>
        <div
          className={`tab ${activeTab === "completed" ? "active" : ""}`}
          onClick={() => setActiveTab("completed")}
        >
          Completed
        </div>
        <div
          className={`tab ${activeTab === "regions" ? "active" : ""}`}
          onClick={() => setActiveTab("regions")}
        >
          Regions
        </div>
      </div>

      {activeTab === "regions" && (
        <div
          className="region-filters"
          style={{
            display: "flex",
            gap: "1rem",
            margin: "1rem 0",
            alignItems: "center",
          }}
        >
          <select
            value={selectedRegion}
            onChange={(e) => {
              setSelectedRegion(e.target.value);
              setSelectedCountry("");
            }}
            style={{ padding: "0.5rem", borderRadius: "6px" }}
          >
            <option value="">Select Region</option>
            {regionOptions.map((region) => (
              <option key={region} value={region}>
                {region}
              </option>
            ))}
          </select>
          <select
            value={selectedCountry}
            onChange={(e) => setSelectedCountry(e.target.value)}
            disabled={!selectedRegion}
            style={{ padding: "0.5rem", borderRadius: "6px" }}
          >
            <option value="">Select Country</option>
            {countryOptions.map((country) => (
              <option key={country} value={country}>
                {country}
              </option>
            ))}
          </select>
          <button
            onClick={() => {
              setSelectedRegion("");
              setSelectedCountry("");
            }}
            style={{
              padding: "0.5rem 1rem",
              border: "1px solid #ccc",
              borderRadius: "6px",
              background: "#f5f5f5",
              cursor: "pointer",
            }}
          >
            Clear Selection
          </button>
        </div>
      )}

      <div className="table-container">
        <table className="project-table">
          <thead>
            <tr>
              <th>Project Name</th>
              <th>Project Manager</th>
              <th>Reporting Manager</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Duration</th>
              <th>Status</th>
              <th>Progress</th>
              <th>Budget</th>
              <th>Client Name</th>
              <th>Country</th>
              <th>Project Overview</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredProjects.length > 0 ? (
              filteredProjects.map((project) => (
                <tr key={project.id}>
                  <td>{project.projectName}</td>
                  <td>{project.projectManager}</td>
                  <td>{project.reportingManager}</td>
                  <td>{project.startDate}</td>
                  <td>{project.endDate}</td>
                  <td>{project.duration}</td>
                  <td>
                    <span
                      className={`status ${getStatusClass(project.status)}`}
                    >
                      {getStatusText(project.status)}
                    </span>
                  </td>
                  <td>
                    <div className="progress-container">
                      <div className="progress-bar">
                        <div
                          className="progress-fill"
                          style={{ width: `${project.progress}%` }}
                        ></div>
                      </div>
                      <span className="progress-text">{project.progress}%</span>
                    </div>
                  </td>
                  <td>{project.budget}</td>
                  <td>{project.clientName}</td>
                  <td>{project.country}</td>
                  <td>
                    <button
                      className="view-project-btn"
                      onClick={() => handleViewProject(project.id)}
                    >
                      View Project
                    </button>
                  </td>
                  <td>
                    <div className="actions-cell">
                      <button
                        className="action-btn edit-btn"
                        onClick={() => handleEditProject(project.id)}
                      >
                        <Edit size={16} />
                      </button>
                      <button
                        className="action-btn delete-btn"
                        onClick={() => handleDeleteProject(project.id)}
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="13" style={{ textAlign: "center" }}>
                  No projects found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ProjectTable;
