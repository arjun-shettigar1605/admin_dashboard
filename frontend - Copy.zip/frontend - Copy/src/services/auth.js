export async function login(email, password) {
  const res = await fetch("http://localhost:8000/api/api/token/", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });

  if (!res.ok) throw new Error("Login failed");

  const data = await res.json();
  console.log("Login response:", data);

  // Store both tokens in one object
  localStorage.setItem(
    "jwt",
    JSON.stringify({
      access: data.access,
      refresh: data.refresh,
    })
  );

  return data; // Return the actual token object
}
