export async function apiFetch(url, options = {}) {
  let access = "";
  let refresh = "";

  try {
    const jwtString = localStorage.getItem("jwt");
    const jwt = JSON.parse(jwtString || "{}");
    access = jwt.access;
    refresh = jwt.refresh;
  } catch (error) {
    console.error("Failed to parse JWT from localStorage:", error);
  }

  let res = await fetch(`http://localhost:8000${url}`, {
    ...options,
    headers: {
      ...(options.headers || {}),
      Authorization: `Bearer ${access}`,
      "Content-Type": "application/json",
    },
  });

  // If access token is expired and refresh token exists
  if (res.status === 401 && refresh) {
    const refreshRes = await fetch(
      "http://localhost:8000/api/api/token/refresh/",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh }),
      }
    );
    if (refreshRes.ok) {
      const data = await refreshRes.json();
      access = data.access;

      // Update localStorage with new access token
      localStorage.setItem("jwt", JSON.stringify({ access, refresh }));

      // Retry original request with new access token
      res = await fetch(`http://localhost:8000${url}`, {
        ...options,
        headers: {
          ...(options.headers || {}),
          Authorization: `Bearer ${access}`,
          "Content-Type": "application/json",
        },
      });
    } else {
      throw new Error("Session expired. Please login again.");
    }
  }
}
